Lab 2: 
Sean Floyd (6778524) & Isaac Shannon (6709038)
